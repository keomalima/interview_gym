# Interview Gym — Batch 02 (125 new exercises)

Together with the original 5 exercises and the 20 in Batch 01, this batch targets **150 exercises in total**.

## Contents

- 125 schemaVersion 1 JSON files under `exercises/`.
- `MANIFEST.json`: IDs, titles, source-inspired groupings, difficulty, counts and priorities.
- `PRIORITIES.json`: Essential / Recommended / Extra labels for all 150 intended exercises. **This sidecar is not importable by the current strict schema.** Codex can implement the optional priority field/filter and merge it later.
- `VALIDATION_REPORT.json`: independent reference checks.

## Import

1. Confirm Batch 01 is already present and check the manifest for duplicate IDs with your **live** catalog.
2. Extract only the `exercises/` tree into your app's repo root.
3. Run `npm run exercises:validate`. Correct any issues in the project's own runtime/validator.
4. Run `npm run exercises:import` on the intended local database.
5. Ask Codex to add an optional priority metadata field and filter if desired; don't copy `PRIORITIES.json` into `exercises/`.

## Notes

Exercises are original, inspired by common interview skills and practice genres, not copied platform problem statements. All run as standalone JS/TS functions with JSON arguments and returns; some async exercises use Promise.resolve to simulate asynchronous work. React, SQL and real backend servers require dedicated runners and are not included.

The test expectations were materialized by executing reference solutions, so an independent implementation review is still worthwhile; validation against the actual app runner is required before import.
